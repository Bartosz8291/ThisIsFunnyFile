THE DOOM IS NEAR -- VIRUS
MADE BY BARTEKK23

So hello, i made another virus! :)
It's now THE DOOM IS NEAR
Yep, the exe is named DOOM
But it's the virus.
This virus does:
Overwrite MBR
Delete System32 (Almost becuse some files are running so it just deleted all files and subdirectoried using cmd /c del /s /q C:\Windows\System32 it takes ownership first)

Btw, idk why the GDI does not work
Go on, try it
Before rebooting, i wanna tell you that it needs time to delete system32 so just wait a few secounds (Like 10 or something)

Malware made in: .NET Framework 4.8 C#
Used IDE: Visual Studio 2022
I used Release Mode so you don't need to install Visual Studio 2022
TRY THIS ONLY IN A VM!
THIS IS FOR EDUCATIONAL AND ENTERTAINMENT PURPOSES ONLY